<?php

/**
 * Dockercontainerdaten
 */
class Modules_Pleskdockerusermanager_List_Dockercontainers
{
    public $dbId;
    public $title;
    public $dockerType;
    public $ipV4;
    public $ipV6;

    public $lastContainerUpdateTime;

    public $mappedFolders;
    public $mappedPorts;
}
